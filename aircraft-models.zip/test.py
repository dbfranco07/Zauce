import numpy as np


x = np.arange(10)
x = np.array(0, 1, 1, 1, )